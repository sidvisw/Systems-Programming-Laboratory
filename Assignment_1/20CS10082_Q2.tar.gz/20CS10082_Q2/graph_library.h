#ifndef MY_LIBRARY2_H
#define MY_LIBRARY2_H

// Incling the header file of graph
#include <lib/graph.h>

#endif